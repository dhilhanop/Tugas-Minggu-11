# Repositories-minggu-11
Codeigniter get data with AJAX
